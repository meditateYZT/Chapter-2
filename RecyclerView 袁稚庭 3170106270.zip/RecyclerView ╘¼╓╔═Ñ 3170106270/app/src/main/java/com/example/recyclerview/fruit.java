package com.example.recyclerview;

 class Fruit {

    private String name;

        public Fruit(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }


