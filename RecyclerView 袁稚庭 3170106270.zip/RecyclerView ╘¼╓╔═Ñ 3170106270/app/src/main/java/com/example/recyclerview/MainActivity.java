package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;



    public class MainActivity extends AppCompatActivity {

        private RecyclerView recyclerView;
        private LinearLayoutManager mLinearLayoutManager;
        private List<Fruit> mFruitList = new ArrayList<>();

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            initFruits();
            recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
            mLinearLayoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(mLinearLayoutManager);
            //添加adapter适配器
            MyAdapter adapter = new MyAdapter(mFruitList);
            recyclerView.setAdapter(adapter);
        }

        private void initFruits() {
            for (int i = 0; i < 2; i++){
                Fruit apple = new Fruit("apple");
                mFruitList.add(apple);
                Fruit orange = new Fruit("orange");
                mFruitList.add(orange);
                Fruit banana = new Fruit("banana");
                mFruitList.add(banana);
                Fruit watermelon = new Fruit("watermelon");
                mFruitList.add(watermelon);
                Fruit pear = new Fruit("pear");
                mFruitList.add(pear);
                Fruit grape = new Fruit("grape");
                mFruitList.add(grape);
            }
        }
    }

}
